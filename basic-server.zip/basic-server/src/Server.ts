import { Agent, createServer, IncomingMessage, ServerResponse } from 'http';
import { userInfo } from 'os';

export class Server {

    public startServer(){
        console.log('Starting server...');
        //createServer().listen(8080);
        //createServer( (req, res) => {}).listen(8080);
        //createServer( (req: IncomingMessage, res: ServerResponse) => {}).listen(8080);
        createServer( 
            (req: IncomingMessage, 
             res: ServerResponse) => {
                 console.log(`Got request from ${req.headers} for ${req.url}`);
                 res.write('Hello from Alex TS servers');
                 res.end();
             })
             .listen(8080);
        console.log('Server started');
        
    }
}